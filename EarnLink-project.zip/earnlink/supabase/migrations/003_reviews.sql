-- 003: verified-student course reviews, moderated by admin. No rewards are paid for reviews.
create table course_reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  product_id uuid not null references products(id),
  rating int not null check (rating between 1 and 5),
  comment text check (char_length(comment) <= 1000),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  unique (user_id, product_id)                 -- one review per student per course
);
alter table course_reviews enable row level security;
create policy read_reviews  on course_reviews for select
  using (status = 'approved' or user_id = auth.uid() or is_admin());
create policy admin_reviews on course_reviews for update using (is_admin()) with check (is_admin());
revoke insert, delete on course_reviews from authenticated, anon;   -- writes only via submit_review

-- Only enrolled (payment-verified) students can review; edits go back to pending.
create or replace function submit_review(p_product uuid, p_rating int, p_comment text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from enrollments where user_id = auth.uid() and product_id = p_product) then
    raise exception 'only enrolled students can review this course'; end if;
  insert into course_reviews(user_id, product_id, rating, comment)
  values (auth.uid(), p_product, p_rating, nullif(trim(p_comment), ''))
  on conflict (user_id, product_id)
  do update set rating = excluded.rating, comment = excluded.comment, status = 'pending';
end $$;

-- Public list shows first name only.
create or replace function public_reviews(p_product uuid)
returns table(rating int, comment text, reviewer text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select r.rating, r.comment, split_part(p.full_name, ' ', 1), r.created_at
  from course_reviews r join profiles p on p.id = r.user_id
  where r.product_id = p_product and r.status = 'approved'
  order by r.created_at desc limit 50
$$;
