-- 002: course content (gated by verified enrollment) + campaign budget guard

-- Budget can only change through verify_campaign_funding / complete_ad (they set a flag).
create or replace function guard_campaign_budget() returns trigger
language plpgsql as $$
begin
  if new.reward_budget_remaining is distinct from old.reward_budget_remaining
     and coalesce(current_setting('earnlink.budget_op', true), '') <> 'on' then
    raise exception 'campaign budget can only change via verified funding or ad rewards';
  end if;
  return new;
end $$;
create trigger campaigns_budget_guard before update on campaigns
  for each row execute function guard_campaign_budget();

create or replace function verify_campaign_funding(p_funding uuid) returns void
language plpgsql security definer set search_path = public as $$
declare f campaign_funding;
begin
  if not is_admin() then raise exception 'admin only'; end if;
  select * into f from campaign_funding where id = p_funding for update;
  if f.verified_at is not null then raise exception 'already verified'; end if;
  perform set_config('earnlink.budget_op','on',true);
  update campaign_funding set verified_by=auth.uid(), verified_at=now() where id = p_funding;
  update campaigns set reward_budget_remaining = reward_budget_remaining + f.reward_budget_allocated
    where id = f.campaign_id;
end $$;

create or replace function complete_ad(p_session uuid) returns numeric
language plpgsql security definer set search_path = public as $$
declare s ad_sessions; a ads; c campaigns; today date := (now() at time zone 'Asia/Karachi')::date;
begin
  select * into s from ad_sessions where id = p_session and user_id = auth.uid() for update;
  if not found or s.completed_at is not null then raise exception 'invalid session'; end if;
  select * into a from ads where id = s.ad_id;
  if now() - s.started_at < make_interval(secs => a.duration_seconds) then
    raise exception 'viewing time not elapsed'; end if;
  select * into c from campaigns where id = a.campaign_id for update;
  if c.reward_budget_remaining < a.reward then raise exception 'reward budget exhausted'; end if;
  if (select count(*) from ad_completions where user_id=auth.uid() and local_day=today)
       >= setting_num('daily_ad_limit') then raise exception 'daily limit reached'; end if;
  update ad_sessions set completed_at = now() where id = p_session;
  insert into ad_completions(session_id,user_id,ad_id,local_day,reward)
    values (p_session,auth.uid(),a.id,today,a.reward);
  perform set_config('earnlink.budget_op','on',true);
  update campaigns set reward_budget_remaining = reward_budget_remaining - a.reward where id = c.id;
  perform post_tx(auth.uid(),'ad_reward',a.reward,'ad:'||p_session,null,null,p_session);
  return a.reward;
end $$;

-- Course content. No lessons are seeded: the admin adds real material
-- (graphics design, video editing, affiliate marketing) before the product can go live.
create table course_modules (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id),
  title text not null,                 -- e.g. Graphics Design / Video Editing / Affiliate Marketing
  display_order int not null default 0
);
create table lessons (
  id uuid primary key default gen_random_uuid(),
  module_id uuid not null references course_modules(id) on delete cascade,
  title text not null,
  video_url text, body text,
  display_order int not null default 0,
  is_published boolean not null default false
);

-- A product can be marked content_ready only if it has at least one published lesson.
create or replace function check_content_ready() returns trigger
language plpgsql as $$
begin
  if new.kind = 'course' and new.content_ready and not exists (
      select 1 from course_modules m join lessons l on l.module_id = m.id
      where m.product_id = new.id and l.is_published) then
    raise exception 'course needs at least one published lesson before it is content-ready';
  end if;
  return new;
end $$;
create trigger products_content_ready before insert or update on products
  for each row execute function check_content_ready();

alter table course_modules enable row level security;
alter table lessons enable row level security;

create policy modules_read on course_modules for select using (
  is_admin() or exists (select 1 from enrollments e
                        where e.user_id = auth.uid() and e.product_id = course_modules.product_id));
create policy lessons_read on lessons for select using (
  is_admin() or (is_published and exists (
    select 1 from course_modules m join enrollments e on e.product_id = m.product_id
    where m.id = lessons.module_id and e.user_id = auth.uid())));
create policy modules_admin on course_modules for all using (is_admin()) with check (is_admin());
create policy lessons_admin on lessons for all using (is_admin()) with check (is_admin());
