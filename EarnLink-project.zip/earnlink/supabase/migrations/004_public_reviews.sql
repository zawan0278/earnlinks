-- 004: approved reviews visible to everyone (logged out too), updating live.
create or replace function public_review_feed()
returns table(rating int, comment text, reviewer text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select r.rating, r.comment, split_part(p.full_name, ' ', 1), r.created_at
  from course_reviews r join profiles p on p.id = r.user_id
  where r.status = 'approved' order by r.created_at desc limit 20
$$;

create or replace function public_review_stats()
returns table(average numeric, total bigint)
language sql stable security definer set search_path = public as $$
  select round(avg(rating)::numeric, 1), count(*) from course_reviews where status = 'approved'
$$;

grant execute on function public_review_feed(), public_review_stats() to anon, authenticated;

-- Live updates: Supabase Realtime streams changes; row-level security still applies.
alter publication supabase_realtime add table course_reviews;
