-- EarnLink core schema v2: revenue-based earning model
-- Money enters the wallet ONLY from (a) admin-verified sales of real products/courses
-- and (b) advertiser-funded campaign reward budgets. Nothing is seeded as demo data.

create extension if not exists pgcrypto;

create type account_status  as enum ('pending','active','suspended','rejected');
create type sale_status     as enum ('pending','verified','rejected','refunded');
create type tx_type         as enum ('ad_reward','commission_l1','commission_l2',
                                     'withdrawal_reserve','withdrawal_release','withdrawal_paid',
                                     'adjustment','reversal');
create type wd_status       as enum ('pending','approved','rejected','paid');
create type campaign_status as enum ('draft','active','paused','ended');

-- ---------- settings (admin-configurable, no code edits) ----------
create table settings (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);
insert into settings(key,value) values
  ('affiliate_enabled','false'),       -- stays off until products + rules are configured
  ('ads_enabled','false'),             -- stays off until a funded campaign exists
  ('withdrawal_increment','600'),
  ('withdrawal_fee','0'),
  ('daily_ad_limit','5'),
  ('max_commission_pct','40'),         -- hard cap: total commissions per sale as % of sale amount
  ('require_account_approval','true');

create or replace function setting_num(k text) returns numeric
language sql stable as $$ select value::numeric from settings where key = k $$;
create or replace function setting_bool(k text) returns boolean
language sql stable as $$ select coalesce((select value = 'true' from settings where key = k), false) $$;

-- ---------- roles & profiles ----------
create table user_roles (
  user_id uuid primary key references auth.users on delete cascade,
  role text not null check (role in ('admin'))
);  -- rows added only by the project owner via SQL; never from the client

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role = 'admin')
$$;

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text not null,
  status account_status not null default 'pending',
  referral_code text not null unique default encode(gen_random_bytes(5),'hex'),
  referred_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  check (referred_by is distinct from id)
);

create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare ref uuid;
begin
  select id into ref from profiles where referral_code = new.raw_user_meta_data->>'ref';
  insert into profiles(id, full_name, status, referred_by)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name','Member'),
          case when setting_bool('require_account_approval') then 'pending' else 'active' end::account_status,
          ref);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

create or replace function guard_profile() returns trigger
language plpgsql as $$
begin
  if not is_admin() and (new.status is distinct from old.status
      or new.referred_by is distinct from old.referred_by
      or new.referral_code is distinct from old.referral_code) then
    raise exception 'protected profile field';
  end if;
  return new;
end $$;
create trigger profiles_guard before update on profiles
  for each row execute function guard_profile();

-- ---------- products, courses, sales, commissions ----------
create table products (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('course','service','product')),
  name text not null,
  description text,
  price numeric(12,2) not null check (price > 0),
  content_ready boolean not null default false,   -- admin confirms real content/delivery exists
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  check (not is_active or content_ready)          -- cannot sell what is not ready
);

create table commission_rules (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references products(id),        -- null = default for all products
  level int not null check (level between 1 and 3),
  kind text not null check (kind in ('fixed','percent')),
  value numeric(12,2) not null check (value > 0),
  is_active boolean not null default false,
  unique nulls not distinct (product_id, level)
);

create table payment_methods (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  account_holder text, account_number text, bank_name text, iban text,
  instructions text,
  is_active boolean not null default false
);

create table sales (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references profiles(id),
  product_id uuid not null references products(id),
  amount numeric(12,2) not null,                  -- copied from product price server-side
  payment_reference text not null,
  screenshot_path text,
  status sale_status not null default 'pending',
  referrer_id uuid references profiles(id),       -- snapshot of buyer's referred_by
  reviewed_by uuid references auth.users,
  reviewed_at timestamptz,
  reject_reason text,
  created_at timestamptz not null default now()
);
create unique index sales_one_open_per_buyer_product
  on sales(buyer_id, product_id) where status in ('pending','verified');
create unique index sales_payment_ref_unique on sales(lower(payment_reference))
  where status in ('pending','verified');

create table enrollments (
  user_id uuid references profiles(id),
  product_id uuid references products(id),
  sale_id uuid not null references sales(id),
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

-- ---------- wallet ledger (append-only, signed amounts) ----------
create table wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  type tx_type not null,
  amount numeric(12,2) not null,                  -- credit +, debit -
  related_sale_id uuid references sales(id),
  related_withdrawal_id uuid,
  related_session_id uuid,
  idempotency_key text not null unique,
  actor uuid,                                     -- admin or null for system
  created_at timestamptz not null default now()
);
create index on wallet_transactions(user_id, created_at desc);

create or replace function block_ledger_mutation() returns trigger
language plpgsql as $$ begin raise exception 'ledger is append-only'; end $$;
create trigger ledger_no_update before update or delete on wallet_transactions
  for each row execute function block_ledger_mutation();

create or replace function wallet_available(uid uuid) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce(sum(amount),0) from wallet_transactions where user_id = uid
$$;

-- ---------- advertisers, campaigns, ads ----------
create table advertisers (
  id uuid primary key default gen_random_uuid(),
  business_name text not null, contact_email text, contact_phone text,
  created_at timestamptz not null default now()
);
create table campaigns (
  id uuid primary key default gen_random_uuid(),
  advertiser_id uuid not null references advertisers(id),
  name text not null,
  status campaign_status not null default 'draft',
  reward_budget_remaining numeric(12,2) not null default 0 check (reward_budget_remaining >= 0),
  starts_on date, ends_on date
);
create table campaign_funding (            -- real advertiser payments, admin-verified
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid not null references campaigns(id),
  amount_paid numeric(12,2) not null check (amount_paid > 0),
  reward_budget_allocated numeric(12,2) not null check (reward_budget_allocated > 0
                                                         and reward_budget_allocated <= amount_paid),
  payment_reference text not null unique,
  verified_by uuid references auth.users,
  verified_at timestamptz
);
create table ads (
  id uuid primary key default gen_random_uuid(),
  campaign_id uuid not null references campaigns(id),
  title text not null, description text,
  ad_type text not null check (ad_type in ('video','image')),
  media_url text, destination_url text,
  duration_seconds int not null check (duration_seconds >= 5),
  reward numeric(12,2) not null check (reward > 0),
  display_order int not null default 0,
  is_active boolean not null default false
);
create table ad_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  ad_id uuid not null references ads(id),
  started_at timestamptz not null default now(),
  completed_at timestamptz
);
create table ad_completions (
  session_id uuid primary key references ad_sessions(id),
  user_id uuid not null references profiles(id),
  ad_id uuid not null references ads(id),
  local_day date not null,                        -- Asia/Karachi calendar day
  reward numeric(12,2) not null,
  unique (user_id, ad_id, local_day)
);

-- ---------- withdrawals, notifications, audit ----------
create table withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  amount numeric(12,2) not null check (amount > 0),
  method text not null check (method in ('easypaisa','jazzcash','bank')),
  account_holder text not null, account_number text not null,
  bank_name text, iban text,
  status wd_status not null default 'pending',
  admin_remarks text, payment_reference text,
  created_at timestamptz not null default now(),
  decided_by uuid references auth.users, decided_at timestamptz, paid_at timestamptz
);
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  title text not null, body text, read_at timestamptz,
  created_at timestamptz not null default now()
);
create table audit_log (
  id bigserial primary key,
  actor uuid, action text not null, entity text, entity_id uuid, detail jsonb,
  created_at timestamptz not null default now()
);

-- ---------- internal helpers ----------
create or replace function post_tx(uid uuid, t tx_type, amt numeric, key text,
    sale uuid default null, wd uuid default null, sess uuid default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into wallet_transactions(user_id,type,amount,idempotency_key,related_sale_id,
      related_withdrawal_id,related_session_id,actor)
  values (uid,t,amt,key,sale,wd,sess,auth.uid())
  on conflict (idempotency_key) do nothing;     -- duplicate requests become no-ops
end $$;
revoke all on function post_tx from public, anon, authenticated;

create or replace function notify(uid uuid, t text, b text) returns void
language sql security definer set search_path = public as
$$ insert into notifications(user_id,title,body) values (uid,t,b) $$;
revoke all on function notify from public, anon, authenticated;

-- ---------- sales workflow ----------
create or replace function submit_sale(p_product uuid, p_reference text, p_screenshot text)
returns uuid language plpgsql security definer set search_path = public as $$
declare prod products; me profiles; sid uuid;
begin
  select * into me from profiles where id = auth.uid();
  if me.status in ('suspended','rejected') then raise exception 'account not allowed'; end if;
  select * into prod from products where id = p_product and is_active;
  if not found then raise exception 'product not available'; end if;
  insert into sales(buyer_id,product_id,amount,payment_reference,screenshot_path,referrer_id)
  values (me.id,prod.id,prod.price,trim(p_reference),p_screenshot,me.referred_by)
  returning id into sid;
  return sid;
end $$;

create or replace function verify_sale(p_sale uuid) returns void
language plpgsql security definer set search_path = public as $$
declare s sales; r record; ben uuid; amt numeric; total numeric := 0; lvl int;
begin
  if not is_admin() then raise exception 'admin only'; end if;
  select * into s from sales where id = p_sale for update;
  if s.status <> 'pending' then raise exception 'sale is not pending'; end if;
  update sales set status='verified', reviewed_by=auth.uid(), reviewed_at=now() where id = p_sale;
  insert into enrollments(user_id,product_id,sale_id) values (s.buyer_id,s.product_id,s.id)
    on conflict do nothing;
  if setting_bool('affiliate_enabled') and s.referrer_id is not null then
    ben := s.referrer_id; lvl := 1;
    while ben is not null and lvl <= 3 loop
      select * into r from commission_rules
        where is_active and level = lvl and (product_id = s.product_id or product_id is null)
        order by product_id nulls last limit 1;
      exit when not found;
      amt := round(case r.kind when 'fixed' then r.value else s.amount * r.value / 100 end, 2);
      -- hard safety cap: all commissions together may not exceed max_commission_pct of the sale
      if total + amt > s.amount * setting_num('max_commission_pct') / 100 then
        exit;
      end if;
      if exists (select 1 from profiles where id = ben and status = 'active') then
        perform post_tx(ben, case lvl when 1 then 'commission_l1' else 'commission_l2' end::tx_type,
                        amt, 'sale:'||s.id||':L'||lvl, s.id);
        perform notify(ben,'Commission credited','Rs. '||amt||' from a verified sale.');
        total := total + amt;
      end if;
      select referred_by into ben from profiles where id = ben;
      lvl := lvl + 1;
    end loop;
  end if;
  insert into audit_log(actor,action,entity,entity_id,detail)
    values (auth.uid(),'sale_verified','sales',p_sale,jsonb_build_object('commissions',total));
end $$;

create or replace function reject_sale(p_sale uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'admin only'; end if;
  update sales set status='rejected', reject_reason=p_reason, reviewed_by=auth.uid(), reviewed_at=now()
    where id = p_sale and status = 'pending';
  if not found then raise exception 'sale is not pending'; end if;
end $$;

create or replace function refund_sale(p_sale uuid) returns void
language plpgsql security definer set search_path = public as $$
declare t record;
begin
  if not is_admin() then raise exception 'admin only'; end if;
  update sales set status='refunded' where id = p_sale and status = 'verified';
  if not found then raise exception 'sale is not verified'; end if;
  delete from enrollments where sale_id = p_sale;
  for t in select * from wallet_transactions
           where related_sale_id = p_sale and type in ('commission_l1','commission_l2') loop
    perform post_tx(t.user_id,'reversal', -t.amount, 'reverse:'||t.id, p_sale);
  end loop;     -- originals stay; a negative balance simply blocks withdrawals
  insert into audit_log(actor,action,entity,entity_id) values (auth.uid(),'sale_refunded','sales',p_sale);
end $$;

-- ---------- ads workflow ----------
create or replace function verify_campaign_funding(p_funding uuid) returns void
language plpgsql security definer set search_path = public as $$
declare f campaign_funding;
begin
  if not is_admin() then raise exception 'admin only'; end if;
  select * into f from campaign_funding where id = p_funding for update;
  if f.verified_at is not null then raise exception 'already verified'; end if;
  update campaign_funding set verified_by=auth.uid(), verified_at=now() where id = p_funding;
  update campaigns set reward_budget_remaining = reward_budget_remaining + f.reward_budget_allocated
    where id = f.campaign_id;
end $$;

create or replace function start_ad_session(p_ad uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare a ads; c campaigns; today date := (now() at time zone 'Asia/Karachi')::date; sid uuid;
begin
  if not setting_bool('ads_enabled') then raise exception 'ads not enabled'; end if;
  if not exists (select 1 from profiles where id = auth.uid() and status='active') then
    raise exception 'account not active'; end if;
  select * into a from ads where id = p_ad and is_active;
  if not found then raise exception 'ad unavailable'; end if;
  select * into c from campaigns where id = a.campaign_id;
  if c.status <> 'active' or c.reward_budget_remaining < a.reward
     or (c.starts_on is not null and today < c.starts_on)
     or (c.ends_on   is not null and today > c.ends_on) then
    raise exception 'campaign not funded or not running'; end if;
  if (select count(*) from ad_completions where user_id = auth.uid() and local_day = today)
       >= setting_num('daily_ad_limit') then raise exception 'daily limit reached'; end if;
  if exists (select 1 from ad_completions where user_id=auth.uid() and ad_id=p_ad and local_day=today) then
    raise exception 'already completed today'; end if;
  insert into ad_sessions(user_id,ad_id) values (auth.uid(),p_ad) returning id into sid;
  return sid;
end $$;

create or replace function complete_ad(p_session uuid) returns numeric
language plpgsql security definer set search_path = public as $$
declare s ad_sessions; a ads; c campaigns; today date := (now() at time zone 'Asia/Karachi')::date;
begin
  select * into s from ad_sessions where id = p_session and user_id = auth.uid() for update;
  if not found or s.completed_at is not null then raise exception 'invalid session'; end if;
  select * into a from ads where id = s.ad_id;
  if now() - s.started_at < make_interval(secs => a.duration_seconds) then
    raise exception 'viewing time not elapsed'; end if;
  select * into c from campaigns where id = a.campaign_id for update;   -- serialises budget use
  if c.reward_budget_remaining < a.reward then raise exception 'reward budget exhausted'; end if;
  if (select count(*) from ad_completions where user_id=auth.uid() and local_day=today)
       >= setting_num('daily_ad_limit') then raise exception 'daily limit reached'; end if;
  update ad_sessions set completed_at = now() where id = p_session;
  insert into ad_completions(session_id,user_id,ad_id,local_day,reward)
    values (p_session,auth.uid(),a.id,today,a.reward);
  update campaigns set reward_budget_remaining = reward_budget_remaining - a.reward where id = c.id;
  perform post_tx(auth.uid(),'ad_reward',a.reward,'ad:'||p_session,null,null,p_session);
  return a.reward;
end $$;

-- ---------- withdrawals ----------
create or replace function request_withdrawal(p_amount numeric, p_method text, p_holder text,
    p_account text, p_bank text, p_iban text) returns uuid
language plpgsql security definer set search_path = public as $$
declare inc numeric := setting_num('withdrawal_increment'); wid uuid;
begin
  perform pg_advisory_xact_lock(hashtext(auth.uid()::text));       -- per-user race protection
  if not exists (select 1 from profiles where id=auth.uid() and status='active') then
    raise exception 'account not active'; end if;
  if p_amount < inc or mod(p_amount, inc) <> 0 then
    raise exception 'amount must be a multiple of %', inc; end if;
  if p_amount > wallet_available(auth.uid()) then raise exception 'insufficient balance'; end if;
  if p_method = 'bank' and (coalesce(p_bank,'')='' or coalesce(p_iban,'')='') then
    raise exception 'bank name and IBAN required'; end if;
  insert into withdrawals(user_id,amount,method,account_holder,account_number,bank_name,iban)
    values (auth.uid(),p_amount,p_method,p_holder,p_account,p_bank,p_iban) returning id into wid;
  perform post_tx(auth.uid(),'withdrawal_reserve',-p_amount,'wd-reserve:'||wid,null,wid);
  return wid;
end $$;

create or replace function admin_decide_withdrawal(p_id uuid, p_action text, p_remarks text, p_ref text)
returns void language plpgsql security definer set search_path = public as $$
declare w withdrawals;
begin
  if not is_admin() then raise exception 'admin only'; end if;
  select * into w from withdrawals where id = p_id for update;
  if p_action = 'approve' and w.status = 'pending' then
    update withdrawals set status='approved', admin_remarks=p_remarks, decided_by=auth.uid(), decided_at=now() where id=p_id;
  elsif p_action = 'reject' and w.status in ('pending','approved') then
    update withdrawals set status='rejected', admin_remarks=p_remarks, decided_by=auth.uid(), decided_at=now() where id=p_id;
    perform post_tx(w.user_id,'withdrawal_release',w.amount,'wd-release:'||p_id,null,p_id);
  elsif p_action = 'paid' and w.status = 'approved' then
    if coalesce(p_ref,'') = '' then raise exception 'payment reference required'; end if;
    update withdrawals set status='paid', payment_reference=p_ref, paid_at=now() where id=p_id;
    perform post_tx(w.user_id,'withdrawal_paid',0,'wd-paid:'||p_id,null,p_id);
  else
    raise exception 'invalid transition from % via %', w.status, p_action;
  end if;
  perform notify(w.user_id,'Withdrawal update','Your withdrawal request is now: '||
                 (select status from withdrawals where id=p_id));
  insert into audit_log(actor,action,entity,entity_id,detail)
    values (auth.uid(),'withdrawal_'||p_action,'withdrawals',p_id,jsonb_build_object('ref',p_ref));
end $$;

-- ---------- Row Level Security ----------
alter table settings enable row level security;          alter table user_roles enable row level security;
alter table profiles enable row level security;          alter table products enable row level security;
alter table commission_rules enable row level security;  alter table payment_methods enable row level security;
alter table sales enable row level security;             alter table enrollments enable row level security;
alter table wallet_transactions enable row level security; alter table advertisers enable row level security;
alter table campaigns enable row level security;         alter table campaign_funding enable row level security;
alter table ads enable row level security;               alter table ad_sessions enable row level security;
alter table ad_completions enable row level security;    alter table withdrawals enable row level security;
alter table notifications enable row level security;     alter table audit_log enable row level security;

-- members read their own rows; writes happen only through the functions above
create policy own_profile   on profiles for select using (id = auth.uid() or is_admin());
create policy own_profile_u on profiles for update using (id = auth.uid() or is_admin());
create policy team_view     on profiles for select using (referred_by = auth.uid());
create policy own_sales     on sales for select using (buyer_id = auth.uid() or is_admin());
create policy own_enroll    on enrollments for select using (user_id = auth.uid() or is_admin());
create policy own_ledger    on wallet_transactions for select using (user_id = auth.uid() or is_admin());
create policy own_wd        on withdrawals for select using (user_id = auth.uid() or is_admin());
create policy own_notif     on notifications for select using (user_id = auth.uid() or is_admin());
create policy own_notif_u   on notifications for update using (user_id = auth.uid());
create policy own_sessions  on ad_sessions for select using (user_id = auth.uid() or is_admin());
create policy own_complet   on ad_completions for select using (user_id = auth.uid() or is_admin());

create policy read_products on products for select using (is_active or is_admin());
create policy read_ads      on ads for select using (is_active or is_admin());
create policy read_methods  on payment_methods for select using (is_active or is_admin());
create policy read_settings on settings for select using (true);

create policy admin_products  on products for all using (is_admin()) with check (is_admin());
create policy admin_rules     on commission_rules for all using (is_admin()) with check (is_admin());
create policy admin_methods   on payment_methods for all using (is_admin()) with check (is_admin());
create policy admin_settings  on settings for all using (is_admin()) with check (is_admin());
create policy admin_advert    on advertisers for all using (is_admin()) with check (is_admin());
create policy admin_campaigns on campaigns for all using (is_admin()) with check (is_admin());
create policy admin_funding   on campaign_funding for all using (is_admin()) with check (is_admin());
create policy admin_ads       on ads for all using (is_admin()) with check (is_admin());
create policy admin_audit     on audit_log for select using (is_admin());

-- no client may change the ledger, sales status, or withdrawals directly
revoke insert, update, delete on wallet_transactions, withdrawals, sales, enrollments,
       ad_sessions, ad_completions from authenticated, anon;
