import { useEffect, useState } from 'react'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'
import { fmt } from '../lib/ledger'

export default function Team() {
  const { profile } = useAuth()
  const [team, setTeam] = useState<{ id: string; full_name: string; status: string; created_at: string }[]>([])
  const [com, setCom] = useState<{ type: string; amount: number; created_at: string }[]>([])
  useEffect(() => {
    if (!profile) return
    supabase.from('profiles').select('id,full_name,status,created_at').eq('referred_by', profile.id).then(r => setTeam((r.data as any) ?? []))
    supabase.from('wallet_transactions').select('type,amount,created_at').eq('user_id', profile.id)
      .in('type', ['commission_l1', 'commission_l2', 'reversal']).order('created_at', { ascending: false }).then(r => setCom((r.data as any) ?? []))
  }, [profile])
  if (!profile) return null
  const link = `${window.location.origin}/register?ref=${profile.referral_code}`
  return (
    <>
      <section className="card"><h3>Your referral link</h3><code style={{ wordBreak: 'break-all' }}>{link}</code>
        <p>Code: <b>{profile.referral_code}</b></p>
        <div className="row"><button className="ghost" onClick={() => navigator.clipboard.writeText(link)}>Copy link</button>
          {'share' in navigator && <button className="ghost" onClick={() => navigator.share({ title: 'EarnLink', url: link })}>Share</button>}</div>
        <p><small>You earn commission only when someone you referred buys a product and an admin verifies the sale. Signing up alone earns nothing, and earnings are not guaranteed.</small></p></section>
      <h3>Direct referrals ({team.length})</h3>
      {team.length === 0 ? <p>Nobody has joined with your link yet.</p> : team.map(t =>
        <div className="line" key={t.id}><span>{t.full_name}</span><small>{t.status} · {new Date(t.created_at).toLocaleDateString()}</small></div>)}
      <h3>Commission history</h3>
      {com.length === 0 ? <p>No commissions yet.</p> : com.map((c, i) =>
        <div className="line" key={i}><span>{c.type.replace(/_/g, ' ')} · {new Date(c.created_at).toLocaleDateString()}</span><b>{fmt(Number(c.amount))}</b></div>)}
    </>)
}
