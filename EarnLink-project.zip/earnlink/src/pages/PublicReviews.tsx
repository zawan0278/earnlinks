import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

type R = { rating: number; comment: string | null; reviewer: string; created_at: string }

export default function PublicReviews() {
  const [rows, setRows] = useState<R[]>([]); const [stats, setStats] = useState<{ average: number | null; total: number } | null>(null)
  useEffect(() => {
    const load = async () => {
      const f = await supabase.rpc('public_review_feed'); setRows((f.data as R[]) ?? [])
      const s = await supabase.rpc('public_review_stats'); const x = (s.data as any)?.[0]
      setStats(x ? { average: x.average === null ? null : Number(x.average), total: Number(x.total) } : null)
    }
    load()
    const ch = supabase.channel('reviews-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'course_reviews' }, load).subscribe()
    const t = setInterval(load, 60000)           // fallback if realtime is not enabled
    return () => { clearInterval(t); supabase.removeChannel(ch) }
  }, [])
  return (
    <section style={{ maxWidth: 420, margin: '0 auto 32px', display: 'grid', gap: 10 }}>
      <h3 style={{ margin: 0 }}>Student reviews{stats?.average != null && ` · ${stats.average} / 5 (${stats.total})`}</h3>
      {rows.length === 0 ? <p>Reviews from verified students will appear here.</p> : rows.map((r, i) =>
        <div className="card" key={i}><b>{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</b> {r.reviewer}
          <p style={{ margin: '4px 0' }}>{r.comment}</p><small>{new Date(r.created_at).toLocaleDateString()}</small></div>)}
    </section>)
}
