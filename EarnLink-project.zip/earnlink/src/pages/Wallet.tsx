import { FormEvent, useEffect, useState } from 'react'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'
import { fmt, summarize, Tx } from '../lib/ledger'

type W = { id: string; amount: number; method: string; status: string; payment_reference: string | null;
  admin_remarks: string | null; created_at: string; account_number: string }
const mask = (n: string) => n.length > 4 ? '•'.repeat(n.length - 4) + n.slice(-4) : n

export default function Wallet() {
  const { profile } = useAuth()
  const [tx, setTx] = useState<Tx[]>([]); const [wd, setWd] = useState<W[]>([]); const [inc, setInc] = useState(600)
  const [f, setF] = useState({ method: 'easypaisa', holder: '', account: '', bank: '', iban: '', amount: '' })
  const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false)
  async function load() {
    if (!profile) return
    const t = await supabase.from('wallet_transactions').select('type,amount,created_at').eq('user_id', profile.id).order('created_at', { ascending: false })
    const w = await supabase.from('withdrawals').select('*').eq('user_id', profile.id).order('created_at', { ascending: false })
    const s = await supabase.from('settings').select('value').eq('key', 'withdrawal_increment').single()
    setTx((t.data as Tx[]) ?? []); setWd((w.data as W[]) ?? []); if (s.data) setInc(Number(s.data.value))
  }
  useEffect(() => { load() }, [profile])
  const s = summarize(tx, wd)
  async function submit(e: FormEvent) {
    e.preventDefault(); setMsg(''); const amount = Number(f.amount)
    if (!amount || amount < inc || amount % inc !== 0) return setMsg(`Amount must be a multiple of ${fmt(inc)}.`)
    if (amount > s.balance) return setMsg('Amount is more than your available balance.')
    setBusy(true)   // the server re-checks everything; this is only a convenience check
    const { error } = await supabase.rpc('request_withdrawal', { p_amount: amount, p_method: f.method,
      p_holder: f.holder, p_account: f.account, p_bank: f.bank || null, p_iban: f.iban || null })
    setMsg(error ? error.message : 'Withdrawal requested. It is pending admin review.')
    if (!error) { setF({ ...f, amount: '' }); load() }
    setBusy(false)
  }
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value })
  return (
    <>
      <section className="card"><small>Available balance</small><b>{fmt(s.balance)}</b>
        <p>Pending: {fmt(s.pending)} · Paid out: {fmt(s.paid)}</p></section>
      <form className="card" onSubmit={submit}>
        <h3>Withdraw funds</h3>
        <p>Amounts must be multiples of {fmt(inc)}. Payouts are made manually after admin approval.</p>
        <label>Method<select value={f.method} onChange={set('method')}>
          <option value="easypaisa">Easypaisa</option><option value="jazzcash">JazzCash</option><option value="bank">Bank transfer</option></select></label>
        <label>Account holder name<input required value={f.holder} onChange={set('holder')} /></label>
        <label>{f.method === 'bank' ? 'Account number' : 'Mobile number'}<input required value={f.account} onChange={set('account')} /></label>
        {f.method === 'bank' && <>
          <label>Bank name<input required value={f.bank} onChange={set('bank')} /></label>
          <label>IBAN<input required value={f.iban} onChange={set('iban')} /></label></>}
        <label>Amount (PKR)<input type="number" required value={f.amount} onChange={set('amount')} /></label>
        {msg && <p className="msg">{msg}</p>}
        <button className="primary" disabled={busy}>{busy ? 'Submitting…' : 'Request withdrawal'}</button>
      </form>
      <h3>Withdrawal records</h3>
      {wd.length === 0 ? <p>No withdrawal requests yet.</p> : wd.map(w =>
        <div className="card" key={w.id}><b>{fmt(Number(w.amount))}</b> · {w.method} · {mask(w.account_number)}
          <p>Status: <b>{w.status}</b>{w.payment_reference && ` · Ref ${w.payment_reference}`}{w.admin_remarks && ` · ${w.admin_remarks}`}</p>
          <small>{new Date(w.created_at).toLocaleString()}</small></div>)}
      <h3>Transaction history</h3>
      {tx.length === 0 ? <p>No transactions yet.</p> : tx.map((t, i) =>
        <div className="line" key={i}><span>{t.type.replace(/_/g, ' ')} · {new Date(t.created_at).toLocaleDateString()}</span>
          <b>{fmt(Number(t.amount))}</b></div>)}
    </>
  )
}
