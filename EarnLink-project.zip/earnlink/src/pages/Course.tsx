import { FormEvent, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'
import { fmt } from '../lib/ledger'
import Reviews from './Reviews'

type Product = { id: string; name: string; description: string | null; price: number }
type Method = { id: string; name: string; account_holder: string | null; account_number: string | null;
  bank_name: string | null; iban: string | null; instructions: string | null }
type Module = { id: string; title: string; lessons: { id: string; title: string; video_url: string | null; body: string | null }[] }

export default function Course() {
  const { profile } = useAuth()
  const [prod, setProd] = useState<Product | null>(null); const [methods, setMethods] = useState<Method[]>([])
  const [sale, setSale] = useState<{ status: string; reject_reason: string | null } | null>(null)
  const [enrolled, setEnrolled] = useState(false); const [mods, setMods] = useState<Module[]>([])
  const [ref, setRef] = useState(''); const [file, setFile] = useState<File | null>(null)
  const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false); const [ready, setReady] = useState(false)

  async function load() {
    if (!profile) return
    const p = await supabase.from('products').select('id,name,description,price').eq('kind', 'course').eq('is_active', true).limit(1)
    const pr = (p.data?.[0] as Product) ?? null; setProd(pr)
    const m = await supabase.from('payment_methods').select('*').eq('is_active', true); setMethods((m.data as Method[]) ?? [])
    if (pr) {
      const s = await supabase.from('sales').select('status,reject_reason').eq('buyer_id', profile.id).eq('product_id', pr.id)
        .order('created_at', { ascending: false }).limit(1); setSale(s.data?.[0] ?? null)
      const e = await supabase.from('enrollments').select('product_id').eq('user_id', profile.id).eq('product_id', pr.id)
      const ok = (e.data?.length ?? 0) > 0; setEnrolled(ok)
      if (ok) { const c = await supabase.from('course_modules').select('id,title,lessons(id,title,video_url,body)')
        .eq('product_id', pr.id).order('display_order'); setMods((c.data as Module[]) ?? []) }
    }
    setReady(true)
  }
  useEffect(() => { load() }, [profile])

  async function submit(e: FormEvent) {
    e.preventDefault(); if (!prod || !profile) return; setBusy(true); setMsg('')
    let path: string | null = null
    if (file) {
      path = `${profile.id}/${Date.now()}-${file.name}`
      const up = await supabase.storage.from('payment-screenshots').upload(path, file)
      if (up.error) { setMsg(`Screenshot upload failed: ${up.error.message}`); setBusy(false); return }
    }
    const { error } = await supabase.rpc('submit_sale', { p_product: prod.id, p_reference: ref, p_screenshot: path })
    setMsg(error ? error.message : 'Payment submitted. An admin will verify it.'); if (!error) load(); setBusy(false)
  }

  if (!ready) return <p>Loading…</p>
  if (!prod) return <div className="card">No course is available yet. An admin must publish one first.</div>
  return (
    <>
      <section className="card"><h2>{prod.name}</h2><p>{prod.description}</p><b>{fmt(Number(prod.price))}</b></section>
      {enrolled ? (
        <>{mods.length === 0 ? <p>Lessons are being added.</p> : mods.map(m =>
          <section className="card" key={m.id}><h3>{m.title}</h3>
            {m.lessons.map(l => <div key={l.id} className="line"><span>{l.title}</span>
              {l.video_url && <Link to={`/lecture/${l.id}`}>▶ Watch</Link>}</div>)}</section>)}</>
      ) : sale?.status === 'pending' ? <div className="card">Your payment is awaiting admin verification.</div> : (
        <>
          <h3>How to pay</h3>
          {methods.length === 0 ? <p>Payment details have not been added yet. Please check back soon.</p> : methods.map(m =>
            <div className="card" key={m.id}><b>{m.name}</b><p>{m.account_holder} · {m.account_number} {m.bank_name} {m.iban}</p>
              <p>{m.instructions}</p>
              {m.account_number && <button className="ghost" onClick={() => navigator.clipboard.writeText(m.account_number!)}>Copy number</button>}</div>)}
          <form className="card" onSubmit={submit}>
            {sale?.status === 'rejected' && <p className="msg">Last payment was rejected: {sale.reject_reason}</p>}
            <label>Transaction ID<input required value={ref} onChange={e => setRef(e.target.value)} /></label>
            <label>Payment screenshot<input type="file" accept="image/*" onChange={e => setFile(e.target.files?.[0] ?? null)} /></label>
            {msg && <p className="msg">{msg}</p>}
            <button className="primary" disabled={busy || methods.length === 0}>{busy ? 'Submitting…' : 'Submit payment'}</button>
          </form>
        </>
      )}
      <Reviews productId={prod.id} enrolled={enrolled} />
    </>
  )
}
