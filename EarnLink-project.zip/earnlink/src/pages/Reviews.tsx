import { FormEvent, useEffect, useState } from 'react'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'

type R = { rating: number; comment: string | null; reviewer: string; created_at: string }

export default function Reviews({ productId, enrolled }: { productId: string; enrolled: boolean }) {
  const { profile } = useAuth()
  const [rows, setRows] = useState<R[]>([]); const [mine, setMine] = useState<{ status: string } | null>(null)
  const [rating, setRating] = useState(5); const [comment, setComment] = useState(''); const [msg, setMsg] = useState('')
  const load = async () => {
    const r = await supabase.rpc('public_reviews', { p_product: productId }); setRows((r.data as R[]) ?? [])
    if (profile) { const m = await supabase.from('course_reviews').select('status').eq('user_id', profile.id).eq('product_id', productId).maybeSingle(); setMine(m.data) }
  }
  useEffect(() => { load() }, [productId, profile])
  async function submit(e: FormEvent) {
    e.preventDefault()
    const { error } = await supabase.rpc('submit_review', { p_product: productId, p_rating: rating, p_comment: comment })
    setMsg(error ? error.message : 'Thanks. Your review will appear after admin approval.'); if (!error) load()
  }
  const avg = rows.length ? (rows.reduce((s, r) => s + r.rating, 0) / rows.length).toFixed(1) : null
  return (
    <>
      <h3>Student reviews{avg && ` · ${avg} / 5 (${rows.length})`}</h3>
      {rows.length === 0 ? <p>No reviews yet. Only students who completed payment can leave one.</p> : rows.map((r, i) =>
        <div className="card" key={i}><b>{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</b> {r.reviewer}
          <p>{r.comment}</p><small>{new Date(r.created_at).toLocaleDateString()}</small></div>)}
      {enrolled && (
        <form className="card" onSubmit={submit}>
          <b>{mine ? `Your review (${mine.status}). Editing sends it back for approval.` : 'Write a review'}</b>
          <label>Rating<select value={rating} onChange={e => setRating(Number(e.target.value))}>
            {[5, 4, 3, 2, 1].map(n => <option key={n} value={n}>{n} stars</option>)}</select></label>
          <label>Comment<textarea maxLength={1000} value={comment} onChange={e => setComment(e.target.value)} /></label>
          {msg && <p className="msg">{msg}</p>}<button className="primary">Submit review</button>
        </form>)}
    </>)
}
