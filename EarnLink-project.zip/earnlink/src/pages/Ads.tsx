import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { fmt } from '../lib/ledger'

type Ad = { id: string; title: string; description: string | null; ad_type: string; media_url: string | null;
  destination_url: string | null; duration_seconds: number; reward: number }

export default function Ads() {
  const [on, setOn] = useState<boolean | null>(null); const [ads, setAds] = useState<Ad[]>([])
  const [cur, setCur] = useState<{ ad: Ad; sid: string; left: number } | null>(null); const [msg, setMsg] = useState('')
  useEffect(() => {
    supabase.from('settings').select('value').eq('key', 'ads_enabled').single().then(r => setOn(r.data?.value === 'true'))
    supabase.from('ads').select('*').eq('is_active', true).order('display_order').then(r => setAds((r.data as Ad[]) ?? []))
  }, [])
  useEffect(() => {
    if (!cur || cur.left <= 0) return
    const t = setTimeout(() => setCur({ ...cur, left: cur.left - 1 }), 1000); return () => clearTimeout(t)
  }, [cur])
  async function start(ad: Ad) {
    const { data, error } = await supabase.rpc('start_ad_session', { p_ad: ad.id })
    if (error) return setMsg(error.message)
    setMsg(''); setCur({ ad, sid: data as string, left: ad.duration_seconds + 1 })
  }
  async function finish() {
    const { data, error } = await supabase.rpc('complete_ad', { p_session: cur!.sid })
    setMsg(error ? error.message : `Done. ${fmt(Number(data))} was added to your wallet.`); setCur(null)
  }
  if (on === null) return <p>Loading…</p>
  if (!on) return <div className="card">Ads Watch is not active yet. It opens when an advertiser has funded a campaign.</div>
  if (cur) return (
    <section className="card"><h3>{cur.ad.title}</h3><p>{cur.ad.description}</p>
      {cur.ad.ad_type === 'image' && cur.ad.media_url && <img src={cur.ad.media_url} alt={cur.ad.title} style={{ maxWidth: '100%', borderRadius: 8 }} />}
      {cur.ad.ad_type === 'video' && cur.ad.media_url && <p><a href={cur.ad.media_url} target="_blank" rel="noreferrer">Open the video</a></p>}
      {cur.ad.destination_url && <p><a href={cur.ad.destination_url} target="_blank" rel="noreferrer">Visit advertiser</a></p>}
      <p>{cur.left > 0 ? `Keep this open: ${cur.left}s left` : 'Time is up. You can claim your reward.'}</p>
      <small>The server checks the elapsed time. The timer shows time, not attention.</small>
      <button className="primary" disabled={cur.left > 0} onClick={finish}>Claim {fmt(Number(cur.ad.reward))}</button></section>)
  return (
    <>{msg && <p className="msg">{msg}</p>}
      {ads.length === 0 ? <div className="card">No ads are available right now.</div> : ads.map(a =>
        <div className="card" key={a.id}><b>{a.title}</b><p>{a.description}</p>
          <small>{a.duration_seconds}s · reward {fmt(Number(a.reward))}</small>
          <button className="primary" onClick={() => start(a)}>Start</button></div>)}</>)
}
