import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'
import { fmt, summarize, Tx, Wd } from '../lib/ledger'

export default function Dashboard() {
  const { profile } = useAuth()
  const [tx, setTx] = useState<Tx[]>([]); const [wd, setWd] = useState<Wd[]>([])
  const [adsDone, setAdsDone] = useState(0); const [limit, setLimit] = useState<number | null>(null)
  useEffect(() => {
    if (!profile) return
    supabase.from('wallet_transactions').select('type,amount,created_at').eq('user_id', profile.id)
      .order('created_at', { ascending: false }).then(r => setTx((r.data as Tx[]) ?? []))
    supabase.from('withdrawals').select('amount,status').eq('user_id', profile.id).then(r => setWd((r.data as Wd[]) ?? []))
    supabase.from('settings').select('value').eq('key', 'daily_ad_limit').single().then(r => r.data && setLimit(Number(r.data.value)))
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Karachi' })
    supabase.from('ad_completions').select('session_id', { count: 'exact', head: true })
      .eq('user_id', profile.id).eq('local_day', today).then(r => setAdsDone(r.count ?? 0))
  }, [profile])
  if (!profile) return null
  const s = summarize(tx, wd)
  const cards: [string, string][] = [['Available balance', fmt(s.balance)], ['Ad earnings today', fmt(s.adsToday)],
    ['Total ad earnings', fmt(s.adsTotal)], ['Direct commissions', fmt(s.direct)], ['Level 2 bonuses', fmt(s.level2)],
    ['Pending withdrawals', fmt(s.pending)], ['Total paid out', fmt(s.paid)]]
  return (
    <>
      <section className="card">
        <h2>{profile.full_name}</h2>
        <p>Account: <b>{profile.status}</b> · Referral code: <b>{profile.referral_code}</b></p>
        {profile.status === 'pending' && <p className="msg">Your account is waiting for admin approval.</p>}
        {profile.status === 'suspended' && <p className="msg">Your account is suspended. Contact support.</p>}
        <p>Share: <code>{window.location.origin}/register?ref={profile.referral_code}</code></p>
      </section>
      <div className="grid">{cards.map(([k, v]) => <div className="card stat" key={k}><small>{k}</small><b>{v}</b></div>)}</div>
      <section className="card"><small>Ads watched today</small>
        <b>{limit === null ? '—' : `${adsDone} / ${limit}`}</b>
        <p>Ads appear only when an advertiser has funded a campaign. None are available until then.</p></section>
      <div className="row"><Link className="primary btn" to="/course">Course & payment</Link>
        <Link className="ghost btn" to="/wallet">Wallet & withdrawals</Link></div>
      <h3>Recent activity</h3>
      {tx.length === 0 ? <p>No earnings yet.</p> : tx.slice(0, 8).map((t, i) =>
        <div className="line" key={i}><span>{t.type.replace(/_/g, ' ')}</span><b>{fmt(Number(t.amount))}</b></div>)}
    </>
  )
}
