import { FormEvent, useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import PublicReviews from './PublicReviews'

const REF_KEY = 'earnlink_ref'

export function Login() {
  const [email, setEmail] = useState(''); const [pw, setPw] = useState('')
  const [show, setShow] = useState(false); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setErr('')
    const { error } = await supabase.auth.signInWithPassword({ email, password: pw })
    if (error) setErr(error.message); setBusy(false)
  }
  async function forgot() {
    if (!email) return setErr('Enter your email first, then tap Forgot password.')
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin })
    setErr(error ? error.message : 'Password reset email sent. Check your inbox.')
  }
  return (
    <>
    <form className="card auth" onSubmit={submit}>
      <h1 className="brand">Earn<span>Link</span></h1>
      <label>Email<input type="email" required value={email} onChange={e => setEmail(e.target.value)} /></label>
      <label>Password
        <div className="row"><input type={show ? 'text' : 'password'} required value={pw} onChange={e => setPw(e.target.value)} />
          <button type="button" className="ghost" onClick={() => setShow(!show)}>{show ? 'Hide' : 'Show'}</button></div></label>
      {err && <p className="msg">{err}</p>}
      <button className="primary" disabled={busy}>{busy ? 'Signing in…' : 'Log in'}</button>
      <button type="button" className="link" onClick={forgot}>Forgot password?</button>
      <p>New here? <Link to="/register">Create an account</Link></p>
    </form>
    <PublicReviews />
    </>
  )
}

export function Register() {
  const [params] = useSearchParams()
  const [f, setF] = useState({ name: '', email: '', pw: '', pw2: '', ref: '' })
  const [terms, setTerms] = useState(false); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false)
  useEffect(() => {                       // keep the referral through the whole signup
    const r = params.get('ref'); if (r) localStorage.setItem(REF_KEY, r)
    setF(x => ({ ...x, ref: r ?? localStorage.getItem(REF_KEY) ?? '' }))
  }, [params])
  async function submit(e: FormEvent) {
    e.preventDefault(); setMsg('')
    if (f.pw.length < 8) return setMsg('Password must be at least 8 characters.')
    if (f.pw !== f.pw2) return setMsg('Passwords do not match.')
    if (!terms) return setMsg('Accept the terms to continue.')
    setBusy(true)
    const { error } = await supabase.auth.signUp({ email: f.email, password: f.pw,
      options: { data: { full_name: f.name, ref: f.ref || null }, emailRedirectTo: window.location.origin } })
    setMsg(error ? error.message : 'Account created. Verify your email, then wait for admin approval.')
    if (!error) localStorage.removeItem(REF_KEY)
    setBusy(false)
  }
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value })
  return (
    <form className="card auth" onSubmit={submit}>
      <h1 className="brand">Earn<span>Link</span></h1>
      <label>Full name<input required value={f.name} onChange={set('name')} /></label>
      <label>Email<input type="email" required value={f.email} onChange={set('email')} /></label>
      <label>Password<input type="password" required value={f.pw} onChange={set('pw')} /></label>
      <label>Confirm password<input type="password" required value={f.pw2} onChange={set('pw2')} /></label>
      <label>Referral code (optional)<input value={f.ref} onChange={set('ref')} /></label>
      <label className="check"><input type="checkbox" checked={terms} onChange={e => setTerms(e.target.checked)} />
        I accept the terms. Earnings are not guaranteed.</label>
      {msg && <p className="msg">{msg}</p>}
      <button className="primary" disabled={busy}>{busy ? 'Creating…' : 'Create account'}</button>
      <p>Already a member? <Link to="/login">Log in</Link></p>
    </form>
  )
}
