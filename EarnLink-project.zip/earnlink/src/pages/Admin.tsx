import { useEffect, useState, ReactNode, FormEvent } from 'react'
import { supabase } from '../lib/supabase'
import { fmt } from '../lib/ledger'

type Row = Record<string, any>
type Field = { k: string; label: string; t?: 'number' | 'checkbox' | 'select' | 'textarea'; opts?: string[]; ref?: string }
const LABEL: Row = { products: 'name', campaigns: 'name', advertisers: 'business_name', course_modules: 'title' }
const upd = (t: string, id: string, p: Row) => supabase.from(t).update(p).eq('id', id)
const call = (fn: string, a: Row) => supabase.rpc(fn, a)

function Btn({ l, run, done }: { l: string; run: () => PromiseLike<any>; done: () => void }) {
  return <button className="ghost" onClick={async () => { const r = await run(); if (r?.error) alert(r.error.message); done() }}>{l}</button>
}

function Create({ table, fields, title, done }: { table: string; fields: Field[]; title: string; done: () => void }) {
  const [v, setV] = useState<Row>({}); const [refs, setRefs] = useState<Row>({})
  useEffect(() => { fields.filter(f => f.ref).forEach(async f => {
    const r = await supabase.from(f.ref!).select(`id,${LABEL[f.ref!]}`); setRefs(x => ({ ...x, [f.k]: r.data ?? [] })) }) }, [])
  async function submit(e: FormEvent) {
    e.preventDefault(); const o: Row = {}
    fields.forEach(f => { const x = v[f.k]
      o[f.k] = f.t === 'checkbox' ? !!x : f.t === 'select' ? (x ?? f.opts![0]) : x === undefined || x === '' ? null : f.t === 'number' ? Number(x) : x })
    const { error } = await supabase.from(table).insert(o)
    if (error) alert(error.message); else { setV({}); done() }
  }
  const set = (k: string) => (e: any) => setV({ ...v, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })
  return (
    <form className="card" onSubmit={submit}><b>{title}</b>
      {fields.map(f => <label key={f.k}>{f.label}
        {f.ref ? <select value={v[f.k] ?? ''} onChange={set(f.k)}><option value="">Select…</option>
            {(refs[f.k] ?? []).map((r: Row) => <option key={r.id} value={r.id}>{r[LABEL[f.ref!]]}</option>)}</select>
        : f.t === 'select' ? <select value={v[f.k] ?? f.opts![0]} onChange={set(f.k)}>{f.opts!.map(o => <option key={o}>{o}</option>)}</select>
        : f.t === 'checkbox' ? <input type="checkbox" checked={!!v[f.k]} onChange={set(f.k)} />
        : f.t === 'textarea' ? <textarea value={v[f.k] ?? ''} onChange={set(f.k)} />
        : <input type={f.t === 'number' ? 'number' : 'text'} step="any" value={v[f.k] ?? ''} onChange={set(f.k)} />}</label>)}
      <button className="primary">Add</button></form>)
}

function List({ table, cols, order = 'created_at', act, tick }: { table: string; cols: string[]; order?: string;
  act?: (r: Row, done: () => void) => ReactNode; tick: number }) {
  const [rows, setRows] = useState<Row[]>([]); const [n, setN] = useState(0)
  useEffect(() => { supabase.from(table).select('*').order(order, { ascending: false }).limit(100).then(r => setRows(r.data ?? [])) }, [table, tick, n])
  if (!rows.length) return <p>Nothing here yet.</p>
  return <>{rows.map(r => <div className="card" key={r.id ?? r.key}>
    {cols.map(c => <div key={c}><small>{c.replace(/_/g, ' ')}: </small>{String(r[c] ?? '—')}</div>)}
    <div className="row" style={{ flexWrap: 'wrap', marginTop: 8 }}>{act?.(r, () => setN(n + 1))}</div></div>)}</>
}

function Overview() {
  const [s, setS] = useState<Row | null>(null)
  useEffect(() => { (async () => {
    const c = async (t: string, f?: [string, string]) => { let q = supabase.from(t).select('*', { count: 'exact', head: true }); if (f) q = q.eq(f[0], f[1]); return (await q).count ?? 0 }
    const sales = (await supabase.from('sales').select('amount').eq('status', 'verified')).data ?? []
    const led = (await supabase.from('wallet_transactions').select('type,amount').limit(5000)).data ?? []
    const by = (t: string) => led.filter((x: Row) => x.type === t).reduce((a: number, x: Row) => a + Number(x.amount), 0)
    const wd = (await supabase.from('withdrawals').select('amount,status')).data ?? []
    const w = (st: string) => wd.filter((x: Row) => x.status === st).reduce((a: number, x: Row) => a + Number(x.amount), 0)
    setS({ 'Registered members': await c('profiles'), 'Pending approvals': await c('profiles', ['status', 'pending']),
      'Suspended': await c('profiles', ['status', 'suspended']), 'Enrolled students': await c('enrollments'),
      'Payments to verify': await c('sales', ['status', 'pending']), 'Active ads': await c('ads', ['is_active', 'true']),
      'Verified ad completions': await c('ad_completions'),
      'Verified sales volume (gross)': fmt(sales.reduce((a: number, x: Row) => a + Number(x.amount), 0)),
      'Ad rewards credited': fmt(by('ad_reward')), 'Direct commissions credited': fmt(by('commission_l1')),
      'Level 2 bonuses credited': fmt(by('commission_l2')),
      'Withdrawals pending': fmt(w('pending')), 'Approved, awaiting payment': fmt(w('approved')), 'Total paid out': fmt(w('paid')) })
  })() }, [])
  if (!s) return <p>Loading…</p>
  return <><div className="grid">{Object.entries(s).map(([k, v]) => <div className="card stat" key={k}><small>{k}</small><b>{String(v)}</b></div>)}</div>
    <p><small>Gross sales volume is money received, not profit. Course delivery, commissions, ad rewards and payouts come out of it.</small></p></>
}

export default function Admin() {
  const [ok, setOk] = useState<boolean | null>(null); const [tab, setTab] = useState('Overview'); const [tick, setTick] = useState(0)
  useEffect(() => { supabase.rpc('is_admin').then(r => setOk(r.data === true)) }, [])
  if (ok === null) return <p>Loading…</p>
  if (!ok) return <div className="card">This area is for administrators only.</div>
  const bump = () => setTick(tick + 1)
  const toggle = (t: string, r: Row, col: string, d: () => void) => <Btn l={`${col}: ${r[col] ? 'turn off' : 'turn on'}`} run={() => upd(t, r.id, { [col]: !r[col] })} done={d} />
  const tabs: Record<string, ReactNode> = {
    Overview: <Overview />,
    Members: <List table="profiles" tick={tick} cols={['full_name', 'status', 'referral_code', 'referred_by', 'created_at']}
      act={(r, d) => <>{r.status === 'pending' && <><Btn l="Approve" run={() => upd('profiles', r.id, { status: 'active' })} done={d} />
        <Btn l="Reject" run={() => upd('profiles', r.id, { status: 'rejected' })} done={d} /></>}
        {r.status === 'active' && <Btn l="Suspend" run={() => upd('profiles', r.id, { status: 'suspended' })} done={d} />}
        {(r.status === 'suspended' || r.status === 'rejected') && <Btn l="Reactivate" run={() => upd('profiles', r.id, { status: 'active' })} done={d} />}</>} />,
    Payments: <List table="sales" tick={tick} cols={['status', 'amount', 'payment_reference', 'buyer_id', 'reject_reason', 'created_at']}
      act={(r, d) => <>{r.screenshot_path && <button className="ghost" onClick={async () => {
          const u = await supabase.storage.from('payment-screenshots').createSignedUrl(r.screenshot_path, 300)
          u.data ? window.open(u.data.signedUrl) : alert(u.error?.message) }}>View screenshot</button>}
        {r.status === 'pending' && <><Btn l="Verify" run={() => call('verify_sale', { p_sale: r.id })} done={d} />
          <Btn l="Reject" run={() => call('reject_sale', { p_sale: r.id, p_reason: prompt('Reason for rejection?') ?? '' })} done={d} /></>}
        {r.status === 'verified' && <Btn l="Refund" run={() => confirm('Refund and reverse commissions?') ? call('refund_sale', { p_sale: r.id }) : Promise.resolve(null)} done={d} />}</>} />,
    Withdrawals: <List table="withdrawals" tick={tick} cols={['status', 'amount', 'method', 'account_holder', 'account_number', 'bank_name', 'iban', 'payment_reference', 'created_at']}
      act={(r, d) => { const go = (a: string, ref = '') => call('admin_decide_withdrawal', { p_id: r.id, p_action: a, p_remarks: prompt('Admin note (optional)') ?? '', p_ref: ref })
        return <>{r.status === 'pending' && <Btn l="Approve" run={() => go('approve')} done={d} />}
          {r.status === 'approved' && <Btn l="Mark paid" run={() => { const ref = prompt('Payment reference (required)'); return ref ? go('paid', ref) : Promise.resolve(null) }} done={d} />}
          {(r.status === 'pending' || r.status === 'approved') && <Btn l="Reject" run={() => go('reject')} done={d} />}</> }} />,
    Catalog: <>
      <Create title="New product or course" table="products" done={bump} fields={[{ k: 'kind', label: 'Type', t: 'select', opts: ['course', 'service', 'product'] },
        { k: 'name', label: 'Name' }, { k: 'description', label: 'Description', t: 'textarea' }, { k: 'price', label: 'Price (PKR)', t: 'number' }]} />
      <List table="products" tick={tick} cols={['name', 'kind', 'price', 'content_ready', 'is_active']}
        act={(r, d) => <>{toggle('products', r, 'content_ready', d)}{toggle('products', r, 'is_active', d)}</>} />
      <Create title="Course module (e.g. Graphics Design)" table="course_modules" done={bump} fields={[{ k: 'product_id', label: 'Course', ref: 'products' },
        { k: 'title', label: 'Module title' }, { k: 'display_order', label: 'Order', t: 'number' }]} />
      <Create title="Lesson" table="lessons" done={bump} fields={[{ k: 'module_id', label: 'Module', ref: 'course_modules' }, { k: 'title', label: 'Title' },
        { k: 'video_url', label: 'Video URL' }, { k: 'body', label: 'Notes', t: 'textarea' }, { k: 'display_order', label: 'Order', t: 'number' },
        { k: 'is_published', label: 'Published', t: 'checkbox' }]} />
      <Create title="Commission rule (leave product empty for all)" table="commission_rules" done={bump} fields={[{ k: 'product_id', label: 'Product', ref: 'products' },
        { k: 'level', label: 'Level (1 = direct)', t: 'number' }, { k: 'kind', label: 'Kind', t: 'select', opts: ['percent', 'fixed'] },
        { k: 'value', label: 'Value (% or PKR)', t: 'number' }, { k: 'is_active', label: 'Active', t: 'checkbox' }]} />
      <List table="commission_rules" order="level" tick={tick} cols={['level', 'kind', 'value', 'is_active']} act={(r, d) => toggle('commission_rules', r, 'is_active', d)} />
      <Create title="Payment method" table="payment_methods" done={bump} fields={[{ k: 'name', label: 'Name (Easypaisa, JazzCash, Bank)' }, { k: 'account_holder', label: 'Account holder' },
        { k: 'account_number', label: 'Account / mobile number' }, { k: 'bank_name', label: 'Bank name' }, { k: 'iban', label: 'IBAN' },
        { k: 'instructions', label: 'Instructions', t: 'textarea' }, { k: 'is_active', label: 'Active', t: 'checkbox' }]} />
      <List table="payment_methods" order="name" tick={tick} cols={['name', 'account_holder', 'account_number', 'is_active']} act={(r, d) => toggle('payment_methods', r, 'is_active', d)} /></>,
    Ads: <>
      <Create title="Advertiser" table="advertisers" done={bump} fields={[{ k: 'business_name', label: 'Business name' }, { k: 'contact_email', label: 'Email' }, { k: 'contact_phone', label: 'Phone' }]} />
      <Create title="Campaign" table="campaigns" done={bump} fields={[{ k: 'advertiser_id', label: 'Advertiser', ref: 'advertisers' }, { k: 'name', label: 'Name' },
        { k: 'starts_on', label: 'Start (YYYY-MM-DD)' }, { k: 'ends_on', label: 'End (YYYY-MM-DD)' }]} />
      <List table="campaigns" order="name" tick={tick} cols={['name', 'status', 'reward_budget_remaining']}
        act={(r, d) => <>{r.status !== 'active' && <Btn l="Activate" run={() => upd('campaigns', r.id, { status: 'active' })} done={d} />}
          {r.status === 'active' && <Btn l="Pause" run={() => upd('campaigns', r.id, { status: 'paused' })} done={d} />}</>} />
      <Create title="Advertiser payment (record after money is received)" table="campaign_funding" done={bump} fields={[{ k: 'campaign_id', label: 'Campaign', ref: 'campaigns' },
        { k: 'amount_paid', label: 'Amount paid', t: 'number' }, { k: 'reward_budget_allocated', label: 'Part reserved for viewer rewards', t: 'number' }, { k: 'payment_reference', label: 'Payment reference' }]} />
      <List table="campaign_funding" order="payment_reference" tick={tick} cols={['amount_paid', 'reward_budget_allocated', 'payment_reference', 'verified_at']}
        act={(r, d) => !r.verified_at && <Btn l="Verify payment" run={() => call('verify_campaign_funding', { p_funding: r.id })} done={d} />} />
      <Create title="Ad" table="ads" done={bump} fields={[{ k: 'campaign_id', label: 'Campaign', ref: 'campaigns' }, { k: 'title', label: 'Title' }, { k: 'description', label: 'Description', t: 'textarea' },
        { k: 'ad_type', label: 'Type', t: 'select', opts: ['video', 'image'] }, { k: 'media_url', label: 'Media URL' }, { k: 'destination_url', label: 'Destination URL' },
        { k: 'duration_seconds', label: 'Viewing seconds', t: 'number' }, { k: 'reward', label: 'Reward (PKR)', t: 'number' }, { k: 'display_order', label: 'Order', t: 'number' }, { k: 'is_active', label: 'Active', t: 'checkbox' }]} />
      <List table="ads" order="title" tick={tick} cols={['title', 'ad_type', 'duration_seconds', 'reward', 'is_active']} act={(r, d) => toggle('ads', r, 'is_active', d)} /></>,
    Reviews: <List table="course_reviews" tick={tick} cols={['status', 'rating', 'comment', 'user_id', 'created_at']}
      act={(r, d) => <>{r.status !== 'approved' && <Btn l="Approve" run={() => upd('course_reviews', r.id, { status: 'approved' })} done={d} />}
        {r.status !== 'rejected' && <Btn l="Reject" run={() => upd('course_reviews', r.id, { status: 'rejected' })} done={d} />}</>} />,
    Settings: <>
      <button className="ghost" onClick={async () => { const key = prompt('Setting key (e.g. support_contact)'); const value = key && prompt('Value')
        if (key && value !== null && value !== undefined) { const { error } = await supabase.from('settings').upsert({ key, value }); if (error) alert(error.message); bump() } }}>Add setting</button>
      <List table="settings" order="key" tick={tick} cols={['key', 'value']}
        act={(r, d) => <Btn l="Edit value" run={() => { const v = prompt(`New value for ${r.key}`, r.value); return v === null ? Promise.resolve(null) : supabase.from('settings').update({ value: v, updated_at: new Date().toISOString() }).eq('key', r.key) }} done={d} />} /></>,
  }
  return <>
    <div className="tabs">{Object.keys(tabs).map(t => <button key={t} className={t === tab ? 'primary' : 'ghost'} onClick={() => setTab(t)}>{t}</button>)}</div>
    {tabs[tab]}</>
}
