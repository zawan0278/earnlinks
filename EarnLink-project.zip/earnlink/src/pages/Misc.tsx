import { FormEvent, useEffect, useState } from 'react'
import { useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'

export function Notifications() {
  const [rows, setRows] = useState<{ id: string; title: string; body: string | null; read_at: string | null; created_at: string }[]>([])
  const load = () => supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(50).then(r => setRows((r.data as any) ?? []))
  useEffect(() => { load() }, [])
  return <>{rows.length === 0 ? <div className="card">No notifications yet.</div> : rows.map(n =>
    <div className="card" key={n.id} style={{ opacity: n.read_at ? 0.6 : 1 }}><b>{n.title}</b><p>{n.body}</p>
      <small>{new Date(n.created_at).toLocaleString()}</small>
      {!n.read_at && <button className="ghost" onClick={async () => { await supabase.from('notifications').update({ read_at: new Date().toISOString() }).eq('id', n.id); load() }}>Mark as read</button>}</div>)}</>
}

export function Profile() {
  const { profile, reload } = useAuth()
  const [name, setName] = useState(profile?.full_name ?? ''); const [pw, setPw] = useState(''); const [msg, setMsg] = useState('')
  async function save(e: FormEvent) {
    e.preventDefault(); setMsg('')
    const a = await supabase.from('profiles').update({ full_name: name }).eq('id', profile!.id)
    if (a.error) return setMsg(a.error.message)
    if (pw) { if (pw.length < 8) return setMsg('Password must be at least 8 characters.')
      const b = await supabase.auth.updateUser({ password: pw }); if (b.error) return setMsg(b.error.message) }
    setPw(''); reload(); setMsg('Saved.')
  }
  return <form className="card" onSubmit={save}><h3>Profile settings</h3>
    <label>Full name<input required value={name} onChange={e => setName(e.target.value)} /></label>
    <label>New password (optional)<input type="password" value={pw} onChange={e => setPw(e.target.value)} /></label>
    {msg && <p className="msg">{msg}</p>}<button className="primary">Save changes</button></form>
}

export function Support() {
  const [c, setC] = useState<string | null>(null)
  useEffect(() => { supabase.from('settings').select('value').eq('key', 'support_contact').maybeSingle().then(r => setC(r.data?.value ?? '')) }, [])
  return <div className="card"><h3>Support</h3>{c === null ? 'Loading…' : c || 'The admin has not added a support contact yet.'}</div>
}

const Note = () => <p className="msg">Draft text. Have a qualified lawyer review it before launch.</p>
export const Terms = () => <div className="card"><h3>Terms and conditions</h3><Note />
  <p>Earnings are not guaranteed. Commissions are paid only on verified sales of real products or services. Ad rewards are paid only from advertiser-funded budgets, so ads can run out.</p>
  <p>Joining or registering never earns money. Withdrawals are reviewed and paid manually by an admin. Accounts may be suspended for fraud or abuse, and sales may be refunded, which reverses related commissions.</p></div>
export const Privacy = () => <div className="card"><h3>Privacy policy</h3><Note />
  <p>We store your name, email, referral relationships, payment references, uploaded payment screenshots and wallet history to run your account. Admins can see this to verify payments and withdrawals. Passwords are handled by Supabase Auth and are never visible to admins.</p></div>
