import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { embedUrl } from '../lib/embed'

type L = { id: string; title: string; body: string | null; video_url: string | null; display_order: number; module_id: string }

export default function Lecture() {
  const { id } = useParams()
  const [lec, setLec] = useState<L | null>(null)
  const [all, setAll] = useState<L[]>([])
  const [state, setState] = useState<'loading' | 'ok' | 'locked'>('loading')

  useEffect(() => {
    setState('loading')
    // RLS only returns the lesson if this student has a verified purchase
    supabase.from('lessons').select('*').eq('id', id).maybeSingle().then(async r => {
      if (!r.data) return setState('locked')
      setLec(r.data as L)
      const s = await supabase.from('lessons').select('*').eq('module_id', r.data.module_id).order('display_order')
      setAll((s.data as L[]) ?? []); setState('ok')
    })
  }, [id])

  if (state === 'loading') return <p>Loading…</p>
  if (state === 'locked' || !lec) return <div className="card">This lecture is not available. <Link to="/course">Back to course</Link></div>
  const i = all.findIndex(x => x.id === lec.id)
  const em = embedUrl(lec.video_url || '')
  return (
    <section className="card">
      <small>Lecture {i + 1} of {all.length}</small>
      <h3 style={{ margin: '4px 0 8px' }}>{lec.title}</h3>
      {em ? (
        <div style={{ position: 'relative', aspectRatio: '16/9', background: '#000', borderRadius: 12, overflow: 'hidden' }}>
          <iframe src={em} title={lec.title} style={{ width: '100%', height: '100%', border: 0 }}
            allow="autoplay; fullscreen; picture-in-picture" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" />
        </div>
      ) : <p className="msg">The video link is missing or cannot play inside the page. Please contact support.</p>}
      <p>{lec.body}</p>
      <div className="row">
        {i > 0 && <Link className="ghost btn" to={`/lecture/${all[i - 1].id}`}>← Previous</Link>}
        {i < all.length - 1 && <Link className="primary btn" to={`/lecture/${all[i + 1].id}`}>Next →</Link>}
        <Link className="ghost btn" to="/course">Back to course</Link>
      </div>
    </section>
  )
}
