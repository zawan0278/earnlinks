import { useEffect, useState } from 'react'
import { Link, Navigate, NavLink, Route, Routes, useNavigate } from 'react-router-dom'
import { useAuth } from './lib/auth'
import { configured, supabase } from './lib/supabase'
import { Login, Register } from './pages/Auth'
import Dashboard from './pages/Dashboard'
import Course from './pages/Course'
import Lecture from './pages/Lecture'
import Wallet from './pages/Wallet'
import Ads from './pages/Ads'
import Team from './pages/Team'
import Admin from './pages/Admin'
import { Notifications, Profile, Support, Terms, Privacy } from './pages/Misc'

function Shell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false); const [admin, setAdmin] = useState(false); const [unread, setUnread] = useState(0)
  const nav = useNavigate(); const { profile } = useAuth()
  useEffect(() => {
    supabase.rpc('is_admin').then(r => setAdmin(r.data === true))
    supabase.from('notifications').select('id', { count: 'exact', head: true }).is('read_at', null).then(r => setUnread(r.count ?? 0))
  }, [children])
  const items: [string, string][] = [['/', 'Dashboard'], ['/ads', 'Watch Ads'], ['/wallet', 'Wallet, History & Withdrawals'],
    ['/team', 'My Team & Referral Link'], ['/course', 'Course & Payment'], ['/notifications', 'Notifications'],
    ['/profile', 'Profile Settings'], ['/support', 'Support'], ['/terms', 'Terms and Conditions'], ['/privacy', 'Privacy Policy']]
  if (admin) items.push(['/admin', 'Admin Panel'])
  return (
    <div className="shell">
      <header className="bar">
        <button className="icon" aria-label="Menu" onClick={() => setOpen(!open)}>☰</button>
        <strong className="brand">Earn<span>Link</span></strong>
        <Link to="/notifications" className="who" aria-label="Notifications">🔔{unread > 0 ? ` ${unread}` : ''}</Link>
        <span className="who" style={{ marginLeft: 0 }}>{profile?.full_name}</span>
      </header>
      {open && (
        <nav className="menu" onClick={() => setOpen(false)}>
          {items.map(([to, label]) => <NavLink key={to} to={to} end>{label}</NavLink>)}
          <button onClick={async () => { await supabase.auth.signOut(); nav('/login') }}>Log out</button>
        </nav>
      )}
      <main>{children}</main>
    </div>
  )
}

export default function App() {
  const { session, loading } = useAuth()
  if (!configured) return <div className="card" style={{ margin: 24 }}>
    Supabase is not connected. Copy <code>.env.example</code> to <code>.env</code> and add your project URL and anon key.</div>
  if (loading) return <p style={{ padding: 24 }}>Loading…</p>
  const guard = (el: JSX.Element) => session ? <Shell>{el}</Shell> : <Navigate to="/login" replace />
  return (
    <Routes>
      <Route path="/login" element={session ? <Navigate to="/" /> : <Login />} />
      <Route path="/register" element={session ? <Navigate to="/" /> : <Register />} />
      <Route path="/" element={guard(<Dashboard />)} />
      <Route path="/ads" element={guard(<Ads />)} />
      <Route path="/course" element={guard(<Course />)} />
      <Route path="/lecture/:id" element={guard(<Lecture />)} />
      <Route path="/wallet" element={guard(<Wallet />)} />
      <Route path="/team" element={guard(<Team />)} />
      <Route path="/notifications" element={guard(<Notifications />)} />
      <Route path="/profile" element={guard(<Profile />)} />
      <Route path="/support" element={guard(<Support />)} />
      <Route path="/terms" element={guard(<Terms />)} />
      <Route path="/privacy" element={guard(<Privacy />)} />
      <Route path="/admin" element={guard(<Admin />)} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  )
}
