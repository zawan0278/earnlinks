import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { AuthProvider } from './lib/auth'
import App from './App'
import './styles.css'
createRoot(document.getElementById('root')!).render(
  <BrowserRouter><AuthProvider><App /></AuthProvider></BrowserRouter>)
