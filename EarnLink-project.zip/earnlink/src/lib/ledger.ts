export type Tx = { type: string; amount: number; created_at: string }
export type Wd = { amount: number; status: string }
export const fmt = (n: number) => `Rs. ${n.toLocaleString('en-PK')}`
const day = (d: Date | string) =>
  new Date(d).toLocaleDateString('en-CA', { timeZone: 'Asia/Karachi' })   // Karachi calendar day
const sum = (xs: Tx[], t: string, today = false) =>
  xs.filter(x => x.type === t && (!today || day(x.created_at) === day(new Date())))
    .reduce((s, x) => s + Number(x.amount), 0)
export function summarize(tx: Tx[], wd: Wd[]) {
  const w = (st: string[]) => wd.filter(x => st.includes(x.status)).reduce((s, x) => s + Number(x.amount), 0)
  return {
    balance: tx.reduce((s, x) => s + Number(x.amount), 0),
    adsTotal: sum(tx, 'ad_reward'), adsToday: sum(tx, 'ad_reward', true),
    direct: sum(tx, 'commission_l1'), level2: sum(tx, 'commission_l2'),
    pending: w(['pending', 'approved']), paid: w(['paid']),
  }
}
