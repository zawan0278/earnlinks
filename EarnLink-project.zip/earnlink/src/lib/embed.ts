// Turns a pasted lecture link into a player URL that can run INSIDE the website.
// Supported: YouTube (watch, youtu.be, shorts, live), Vimeo, Bunny Stream embeds.
export function embedUrl(link: string): string {
  try {
    const x = new URL(link)
    const h = x.hostname.replace(/^www\./, '')
    const ok = (v: string | null | undefined) => /^[\w-]{6,}$/.test(v || '')
    if (h === 'youtu.be' && ok(x.pathname.slice(1))) return 'https://www.youtube-nocookie.com/embed/' + x.pathname.slice(1)
    if (h === 'youtube.com' || h === 'm.youtube.com') {
      if (x.pathname === '/watch' && ok(x.searchParams.get('v'))) return 'https://www.youtube-nocookie.com/embed/' + x.searchParams.get('v')
      const m = x.pathname.match(/^\/(?:embed|shorts|live)\/([\w-]{6,})/)
      if (m) return 'https://www.youtube-nocookie.com/embed/' + m[1]
    }
    if (h === 'vimeo.com') {
      const id = x.pathname.split('/').filter(Boolean)[0]
      if (/^\d+$/.test(id || '')) return 'https://player.vimeo.com/video/' + id
    }
    if (h === 'player.vimeo.com' || h === 'iframe.mediadelivery.net') return link
  } catch { /* not a valid link */ }
  return ''
}
