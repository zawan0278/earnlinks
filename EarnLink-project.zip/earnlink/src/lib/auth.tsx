import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import { supabase } from './supabase'

export type Profile = { id: string; full_name: string; status: string; referral_code: string }
type AuthCtx = { session: Session | null; profile: Profile | null; loading: boolean; reload: () => void }
const Ctx = createContext<AuthCtx>({ session: null, profile: null, loading: true, reload: () => {} })
export const useAuth = () => useContext(Ctx)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async (s: Session | null) => {
    if (!s) { setProfile(null); setLoading(false); return }
    const { data } = await supabase.from('profiles')
      .select('id,full_name,status,referral_code').eq('id', s.user.id).single()
    setProfile(data); setLoading(false)
  }, [])

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); load(data.session) })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); load(s) })
    return () => sub.subscription.unsubscribe()
  }, [load])

  return <Ctx.Provider value={{ session, profile, loading, reload: () => load(session) }}>{children}</Ctx.Provider>
}
