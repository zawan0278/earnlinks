# EarnLink setup

1. Create a Supabase project. In the SQL editor run `supabase/migrations/001_core.sql`, then `002_course_and_guards.sql`.
2. Storage: create a private bucket named `payment-screenshots`. Add a policy letting authenticated users
   insert into their own folder (`(storage.foldername(name))[1] = auth.uid()::text`) and admins read everything.
3. Make yourself admin (run once in SQL editor, using your own user id from Authentication > Users):
   `insert into user_roles(user_id, role) values ('<your-user-id>', 'admin');`
4. Copy `.env.example` to `.env` and fill in the project URL and anon key. Never add the service-role key.
5. `npm install && npm run dev`

Earning stays off until an admin configures a product, payment methods, and settings
(`affiliate_enabled`, `ads_enabled`). No demo data is created.

## Storage policy for admins
Admins must be able to open payment screenshots. Add a select policy on `storage.objects` for bucket
`payment-screenshots` with `using (bucket_id = 'payment-screenshots' and public.is_admin())`.

## First-run order (as admin, Admin Panel)
1. Catalog: add payment methods, add the course, add modules and at least one published lesson, mark it content-ready, then activate it.
2. Catalog: add a commission rule (percent, level 1) and activate it; Settings: set `affiliate_enabled` to `true`.
3. Ads: add advertiser, campaign, record their payment, verify it, add ads, activate; Settings: set `ads_enabled` to `true`.
4. Settings: add `support_contact`.
